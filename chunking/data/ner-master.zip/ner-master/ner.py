import argparse

parser = argparse.ArgumentParser("ner.py")

args = parser.parse_args()